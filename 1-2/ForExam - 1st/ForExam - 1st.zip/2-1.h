#ifndef Header2_1Included
#define Header2_1Included

struct gujochae{
	int x;
	int y;
	char a;
	char b;
};

gujochae nada[10];

#endif
